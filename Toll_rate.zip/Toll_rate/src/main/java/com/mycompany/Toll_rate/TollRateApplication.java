package com.mycompany.Toll_rate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TollRateApplication {

	public static void main(String[] args) {
		SpringApplication.run(TollRateApplication.class, args);
	}

}
