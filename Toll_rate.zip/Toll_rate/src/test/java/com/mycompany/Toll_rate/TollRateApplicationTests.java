package com.mycompany.Toll_rate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TollRateApplicationTests {

	@Test
	void contextLoads() {
	}

}
